#pragma once
#include <array>

struct Vertex
{
    std::array<float, 3>Position;
    std::array<float, 2>TexCoordinates;
};

